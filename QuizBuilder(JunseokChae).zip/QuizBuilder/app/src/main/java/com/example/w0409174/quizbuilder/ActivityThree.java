package com.example.w0409174.quizbuilder;

import android.support.v7.app.AppCompatActivity;
import android.os.*;
import android.content.Intent;
import android.view.*;
import android.view.View.*;
import android.widget.*;

public class ActivityThree extends AppCompatActivity{
    TextView tvBuildQuiz, tvQuizName, tvQuizNameInput, tvUserName, tvUserNameInput, tvCategory, tvCategoryInput, tvCorrect;
    Button btnYes, btnNo;
    String quizName;
    String userName;
    String category;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity3);
        tvBuildQuiz = (TextView) findViewById(R.id.tvBuildQuiz);
        tvQuizName = (TextView) findViewById(R.id.tvQuizName);
        tvQuizNameInput = (TextView) findViewById(R.id.tvQuizNameInput);
        tvUserName = (TextView) findViewById(R.id.tvUserName);
        tvUserNameInput = (TextView) findViewById(R.id.tvUserNameInput);
        tvCategory = (TextView) findViewById(R.id.tvCategory);
        tvCategoryInput = (TextView) findViewById(R.id.tvCategoryInput);
        tvCorrect = (TextView) findViewById(R.id.tvCorrect);
        btnYes = (Button) findViewById(R.id.btnYes);
        btnNo = (Button) findViewById(R.id.btnNo);
        Bundle extras = getIntent().getExtras();
        if(extras != null){
            quizName = extras.getString("TITLE");
            userName = extras.getString("BUILDER");
            category = extras.getString("CATEGORY");
            tvQuizNameInput.setText(quizName);
            tvUserNameInput.setText(userName);
            tvCategoryInput.setText(category);
        }

        btnYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent("ActivityFour");
                Bundle extras2 = new Bundle();
                extras2.putString("TITLE", quizName);
                extras2.putString("BUILDER", userName);
                extras2.putString("CATEGORY", category);
                i.putExtras(extras2);
                startActivityForResult(i,1);
            }
        });

        btnNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ActivityThree.this, ActivityTwo.class));
            }
        });
    }
}
