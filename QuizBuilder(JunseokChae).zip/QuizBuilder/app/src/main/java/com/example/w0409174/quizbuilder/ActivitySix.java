package com.example.w0409174.quizbuilder;

import android.support.v7.app.AppCompatActivity;
import android.widget.*;
import java.util.*;
import java.io.*;
import android.os.*;
import android.content.Intent;
import android.view.*;

public class ActivitySix extends AppCompatActivity {
    TextView tvQuizName, tvQuestion;
    Button btnAnswer1, btnAnswer2, btnAnswer3, btnAnswer4, btnHome;
    String quizName;
    String userName;
    String fileName;
    String category;
    String mAnswer;
    int mScore;
    int mQuestionNumber = 0;
    ArrayList<ArrayList> questionPool = new ArrayList<ArrayList>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity6);
        tvQuizName = findViewById(R.id.tvQuizName);
        tvQuestion = findViewById(R.id.tvQuestion);
        btnAnswer1 = findViewById(R.id.btnAnswer1);
        btnAnswer2 = findViewById(R.id.btnAnswer2);
        btnAnswer3 = findViewById(R.id.btnAnswer3);
        btnAnswer4 = findViewById(R.id.btnAnswer4);
        btnHome = findViewById(R.id.btnHome);


        Bundle extras = getIntent().getExtras();
        if(extras != null){
            quizName = extras.getString("TITLE");
            userName = extras.getString("BUILDER");
            fileName = extras.getString("FILE");
            category = extras.getString("CATEGORY");
            tvQuizName.setText(quizName);
            questionPool = QuestionLibrary.loadQuiz(new File(fileName));

        }


        updateQuestion();

        btnAnswer1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(btnAnswer1.getText()== mAnswer)
                {

                    mScore+=1;
                    updateQuestion();
                    Toast.makeText(ActivitySix.this,"Correct",Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(ActivitySix.this,"Wrong",Toast.LENGTH_SHORT).show();

                    updateQuestion();
                }
            }
        });
        btnAnswer2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(btnAnswer2.getText()== mAnswer)
                {

                    mScore+=1;
                    updateQuestion();
                    Toast.makeText(ActivitySix.this,"Correct",Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(ActivitySix.this,"Wrong",Toast.LENGTH_SHORT).show();

                    updateQuestion();
                }
            }
        });
        btnAnswer3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(btnAnswer3.getText()== mAnswer)
                {

                    mScore+=1;
                    updateQuestion();
                    Toast.makeText(ActivitySix.this,"Correct",Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(ActivitySix.this,"Wrong",Toast.LENGTH_SHORT).show();

                    updateQuestion();
                }
            }
        });
        btnAnswer4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(btnAnswer4.getText()== mAnswer)
                {

                    mScore+=1;
                    updateQuestion();
                    Toast.makeText(ActivitySix.this,"Correct",Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(ActivitySix.this,"Wrong",Toast.LENGTH_SHORT).show();

                    updateQuestion();
                }
            }
        });

        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ActivitySix.this, MainActivity.class));
            }
        });




    }
    private void updateQuestion()
    {

        try{
            tvQuestion.setText(QuestionLibrary.getQuestion(questionPool,mQuestionNumber));
            String[][] selectionSets = QuestionLibrary.makeSelectionList(questionPool);
            btnAnswer1.setText(selectionSets[mQuestionNumber][0]);
            btnAnswer2.setText(selectionSets[mQuestionNumber][1]);
            btnAnswer3.setText(selectionSets[mQuestionNumber][2]);
            btnAnswer4.setText(selectionSets[mQuestionNumber][3]);
            mAnswer = selectionSets[mQuestionNumber][4];
            mQuestionNumber++;
        }
        catch(Exception e){
            Intent i = new Intent("ActivitySeven");
            Bundle extras = new Bundle();
            extras.putString("BUILDER",userName);
            extras.putString("QUESTIONS",String.valueOf(questionPool.size()));
            extras.putString("SCORE",String.valueOf(mScore));
            extras.putString("TITLE",quizName);
            extras.putString("CATEGORY",category);
            extras.putString("FILE",fileName);
            i.putExtras(extras);
            startActivityForResult(i,1);
        }


    }



}
