package com.example.w0409174.quizbuilder;

import android.support.v7.app.AppCompatActivity;
import android.os.*;
import android.content.Intent;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.provider.*;
import android.database.Cursor;
import java.nio.file.Path;
import java.util.*;
import java.io.*;
import android.net.*;


public class ActivityFour extends AppCompatActivity {
    TextView tvQuizBuilder, tvQuizName,tvBuilderName,tvCategory,tvOpenFile,tvSelectedFile,tvFileName;
    Button btnOpenFile, btnPrevious, btnNext;
    String quizName;
    String userName;
    String category;
    String selectedFilePath;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity4);
        tvQuizBuilder = (TextView) findViewById(R.id.tvQuizBuilder);
        tvQuizName = (TextView) findViewById(R.id.tvQuizName);
        tvBuilderName = (TextView) findViewById(R.id.tvBuilderName);
        tvCategory = (TextView) findViewById(R.id.tvCategory);
        tvOpenFile = (TextView) findViewById(R.id.tvOpenFile);
        tvSelectedFile = (TextView) findViewById(R.id.tvSelectedFile);
        tvFileName = (TextView) findViewById(R.id.tvFileName);
        btnOpenFile = (Button) findViewById(R.id.btnOpenFile);
        btnPrevious = (Button) findViewById(R.id.btnPrevious);
        btnNext = (Button) findViewById(R.id.btnNext);
        Bundle extras = getIntent().getExtras();
        if(extras != null){
            quizName = extras.getString("TITLE");
            userName = extras.getString("BUILDER");
            category = extras.getString("CATEGORY");
            tvQuizName.setText(quizName);
            tvBuilderName.setText(userName);
            tvCategory.setText(category);
        }

        btnOpenFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                Uri uri = Uri.parse(Environment.getExternalStorageDirectory().getPath()
                        +  File.separator + "myFolder" + File.separator);
                intent.setDataAndType(uri, "text/csv");
                startActivityForResult(Intent.createChooser(intent, "Open folder"),1);
                tvFileName.setText(selectedFilePath);
            }
        });

        btnPrevious.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent("ActivityThree");
                Bundle extras = new Bundle();
                extras.putString("TITLE", quizName);
                extras.putString("BUILDER", userName);
                extras.putString("CATEGORY", category);
                i.putExtras(extras);
                startActivityForResult(i,1);

            }
        });

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(selectedFilePath==null)	{
                    Toast.makeText(ActivityFour.this,"Please select file", Toast.LENGTH_LONG).show();
                }
				else{
                Intent i = new Intent("ActivityFive");
				Bundle extras2 = new Bundle();
				extras2.putString("TITLE", quizName);
                extras2.putString("BUILDER", userName);
                extras2.putString("CATEGORY", category);
                extras2.putString("FILE", selectedFilePath);
                i.putExtras(extras2);
                startActivityForResult(i,1);
                }

            }
        });




    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub

        switch(requestCode){

            case 1:

                if(resultCode==RESULT_OK){
                    Uri u = data.getData();
                    //String filePath = Utils.getActualPath(this, u);
                    selectedFilePath = Utils.getRealPath(this, u);
                    /*String PathHolder = data.getData().getPath();
                    String mRelativeFolderPath = "/Download/";  // i.e. SDCard/DCIM/Camera
                    String mBaseFolderPath = Environment.getExternalStorageDirectory().getAbsolutePath() + mRelativeFolderPath;
                    PathHolder= mBaseFolderPath + "quiz.csv";
                    selectedFilePath = PathHolder;*/
                    Toast.makeText(ActivityFour.this, selectedFilePath , Toast.LENGTH_LONG).show();
                    tvFileName.setText(selectedFilePath);


                }
                break;

        }
    }
    private String getRealPathFromURI(Uri contentURI) {
        String result;
        Cursor cursor = getContentResolver().query(contentURI, null, null, null, null);
        if (cursor == null) { // Source is Dropbox or other similar local file path
            result = contentURI.getPath();
        } else {
            cursor.moveToFirst();
            int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            result = cursor.getString(idx);
            cursor.close();
        }
        return result;
    }



}


