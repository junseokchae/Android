package com.example.w0409174.quizbuilder;

import android.support.v7.app.AppCompatActivity;
import android.os.*;
import android.content.Intent;
import android.view.*;
import android.view.View.*;
import android.widget.*;

import java.lang.reflect.Array;
import java.nio.file.Path;
import java.util.*;
import java.io.*;
import android.net.*;
import com.opencsv.CSVReader;

public class ActivityFive extends AppCompatActivity {
    ArrayList<ArrayList> fileContents = new ArrayList<ArrayList>();
	TextView tvQuizBuilder, tvQuizName, tvBuilderName, tvFileName, tvNumberOfQuestions, tvCorrect, tvMade;
	Button btnYes, btnNo;
	String quizName;
	String userName;
	String fileName;
	String category;
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity5);
		
		tvQuizBuilder = findViewById(R.id.tvQuizBuilder);
		tvQuizName = findViewById(R.id.tvQuizName);
		tvBuilderName = findViewById(R.id.tvBuilderName);
		tvFileName = findViewById(R.id.tvFileName);
		tvNumberOfQuestions = findViewById(R.id.tvNumberOfQuestions);
		tvCorrect = findViewById(R.id.tvCorrect);
		tvMade = findViewById(R.id.tvMade);;
		btnYes = findViewById(R.id.btnYes);
		btnNo = findViewById(R.id.btnNo);
		
		Bundle extras = getIntent().getExtras();
		if(extras != null){
            quizName = extras.getString("TITLE");
            userName = extras.getString("BUILDER");
            fileName = extras.getString("FILE");
			category = extras.getString("CATEGORY");
            tvQuizName.setText(quizName);
            tvBuilderName.setText(userName);
			tvFileName.setText(fileName);
		}
        try {
            CSVReader reader = new CSVReader(new FileReader(fileName));

            String[] nextLine;
            while ((nextLine = reader.readNext()) != null) {
                // nextLine[] is an array of values from the line
                System.out.println(nextLine[0] + nextLine[1] + "etc...");
                ArrayList<String> contents = new ArrayList<String> ();
                for(int i=0;i<nextLine.length;i++){
                    contents.add(nextLine[i]);
                }
                fileContents.add(contents);
            }
        } catch (IOException e) {
			e.printStackTrace();
			Toast.makeText(this, "The specified file was not found", Toast.LENGTH_SHORT).show();

        }
        tvNumberOfQuestions.setText("Questions: "+String.valueOf(fileContents.size()));


		btnYes.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {


				Intent i = new Intent("ActivitySix");
				Bundle extras = new Bundle();
				extras.putString("TITLE", quizName);
				extras.putString("BUILDER", userName);
				extras.putString("CATEGORY", category);
				extras.putString("FILE", fileName);
				i.putExtras(extras);
				startActivityForResult(i,1);
			}
		});




		btnNo.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent("ActivityFour");
				Bundle extras2 = new Bundle();
				extras2.putString("TITLE", quizName);
				extras2.putString("BUILDER", userName);
				extras2.putString("CATEGORY", category);
				i.putExtras(extras2);
				startActivityForResult(i,1);
			}
		});
		
		
		
		
	
		
    }    
}
