package com.example.w0409174.quizbuilder;
import com.opencsv.CSVReader;
import java.util.*;
import java.io.*;


public class QuestionLibrary {

    public static ArrayList<ArrayList> loadQuiz(File fileName) {
        ArrayList<ArrayList> fileContents = new ArrayList<ArrayList>();
        try {
            CSVReader reader = new CSVReader(new FileReader(fileName));

            String[] nextLine;
            while ((nextLine = reader.readNext()) != null) {
                // nextLine[] is an array of values from the line
                System.out.println(nextLine[0] + nextLine[1] + "etc...");
                ArrayList<String> contents = new ArrayList<String>();
                for (int i = 0; i < nextLine.length; i++) {
                    contents.add(nextLine[i]);
                }
                fileContents.add(contents);
                Collections.shuffle(fileContents);
            }
        } catch (IOException e) {
            e.printStackTrace();


        }
        return fileContents;

    }

    public static String[][] makeSelectionList(ArrayList<ArrayList> questions){
        String[][] selectionSet = new String[][]{};
        for(int i=0;i<questions.size();i++){
            String[] selectionList = new String[]{};
            selectionList = add(selectionList,(String) questions.get(i).get(1));
            int wrong1 = i;
            while(wrong1 == i){
                wrong1 = new Random().nextInt(questions.size());
            }
            int wrong2 = i;
            while(wrong2 == i || wrong2 == wrong1){
                wrong2 = new Random().nextInt(questions.size());
            }
            int wrong3 = i;
            while(wrong3 == i || wrong3 == wrong1 || wrong3 == wrong2){
                wrong3 = new Random().nextInt(questions.size());
            }
            selectionList = add(selectionList, (String) questions.get(wrong1).get(1));
            selectionList = add(selectionList, (String) questions.get(wrong2).get(1));
            selectionList = add(selectionList, (String) questions.get(wrong3).get(1));
            List<String> listSelectionList = Arrays.asList(selectionList);
            Collections.shuffle(listSelectionList);
            selectionList = listSelectionList.toArray(selectionList);
            selectionList = add(selectionList, (String) questions.get(i).get(1));
            selectionSet = add(selectionSet, selectionList);

        }

        return selectionSet;
    }
    public static String getQuestion(ArrayList<ArrayList> questions, int a) {
        String question = (String) questions.get(a).get(0);
        return question;
    }
    public static String[] add(String[] originalArray, String newItem)
    {
        int currentSize = originalArray.length;
        int newSize = currentSize + 1;
        String[] tempArray = new String[ newSize ];
        for (int i=0; i < currentSize; i++)
        {
            tempArray[i] = originalArray [i];
        }
        tempArray[newSize- 1] = newItem;
        return tempArray;
    }
    public static String[][] add(String[][] originalArray, String[] newItem)
    {
        int currentSize = originalArray.length;
        int newSize = currentSize + 1;
        String[][] tempArray = new String[ newSize ][];
        for (int i=0; i < currentSize; i++)
        {
            tempArray[i] = originalArray [i];
        }
        tempArray[newSize- 1] = newItem;
        return tempArray;
    }




}