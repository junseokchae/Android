package com.example.w0409174.quizbuilder;

import android.support.v7.app.AppCompatActivity;
import android.widget.*;
import android.os.*;
import android.content.Intent;
import android.view.*;

public class ActivitySeven extends AppCompatActivity {
    TextView tvQuizFinished, tvReport, tvBuilderName, tvUserName, tvQuestions, tvNumber, tvCorrectAnswers, tvScore, tvIncorrectAnswers, tvLosePoints, tvRetry;
    Button btnYes, btnNo;
    String userName;
    String questions;
    String score;
    String quizName;
    String category;
    String fileName;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity7);
        tvQuizFinished = findViewById(R.id.tvQuizFinished);
        tvReport = findViewById(R.id.tvReport);
        tvBuilderName = findViewById(R.id.tvBuilderName);
        tvUserName = findViewById(R.id.tvUserName);
        tvQuestions = findViewById(R.id.tvQuestions);
        tvNumber = findViewById(R.id.tvNumber);
        tvCorrectAnswers = findViewById(R.id.tvCorrectAnswers);
        tvScore = findViewById(R.id.tvScore);
        tvIncorrectAnswers = findViewById(R.id.tvIncorrectAnswers);
        tvLosePoints = findViewById(R.id.tvLosePoints);
        tvRetry = findViewById(R.id.tvRetry);

        btnYes = findViewById(R.id.btnYes);
        btnNo = findViewById(R.id.btnNo);

        Bundle extras = getIntent().getExtras();
        if(extras != null){
            userName = extras.getString("BUILDER");
            questions = extras.getString("QUESTIONS");
            score = extras.getString("SCORE");
            quizName = extras.getString("TITLE");
            category = extras.getString("CATEGORY");
            fileName = extras.getString("FILE");
        }
        tvUserName.setText(userName);
        tvNumber.setText(questions);
        tvScore.setText(score);
        String losePoints = String.valueOf(Integer.parseInt(questions) - Integer.parseInt(score));
        tvLosePoints.setText(losePoints);
        btnYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent("ActivitySix");
                Bundle extras = new Bundle();
                extras.putString("TITLE",quizName);
                extras.putString("BUILDER",userName);
                extras.putString("FILE",fileName);
                extras.putString("CATEGORY",category);
                i.putExtras(extras);
                startActivityForResult(i,1);
            }
        });

        btnNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ActivitySeven.this, MainActivity.class));
            }
        });

    }
}
