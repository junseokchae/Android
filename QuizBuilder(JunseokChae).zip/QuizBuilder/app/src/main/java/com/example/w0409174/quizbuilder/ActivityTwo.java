package com.example.w0409174.quizbuilder;

import android.support.v7.app.AppCompatActivity;
import android.os.*;
import android.content.Intent;
import android.view.*;
import android.view.View.*;
import android.widget.*;

import java.util.Locale;

public class ActivityTwo extends AppCompatActivity{
    TextView tvQuizBuilder, tvTitle, tvBuilder, tvCategory;
    EditText etTitle, etBuilder;
    Spinner spinnerCategory;
    Button btnBuildQuiz, btnMainMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity2);

        tvQuizBuilder = (TextView)findViewById(R.id.tvQuizBuilder);
        tvTitle = (TextView)findViewById(R.id.tvTitle);
        tvBuilder = (TextView)findViewById(R.id.tvBuilder);
        tvCategory = (TextView)findViewById(R.id.tvCategory);
        etTitle = (EditText)findViewById(R.id.etTitle);
        etBuilder = (EditText)findViewById(R.id.etBuilder);
        spinnerCategory = (Spinner)findViewById(R.id.spinnerCategory);
        btnBuildQuiz = (Button)findViewById(R.id.btnBuildQuiz);
        btnMainMenu = (Button)findViewById(R.id.btnMainMenu);

        btnBuildQuiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = etTitle.getText().toString();
                String builder = etBuilder.getText().toString();
                if(title.trim().isEmpty()){
                    Toast.makeText(ActivityTwo.this,"Please Enter the Title",Toast.LENGTH_LONG).show();
                }
                else if(builder.trim().isEmpty()){
                    Toast.makeText(ActivityTwo.this,"Please Enter the Builder's Name",Toast.LENGTH_LONG).show();
                }
                else{
                    Intent i = new Intent("ActivityThree");
                    Bundle extras = new Bundle();
                    extras.putString("TITLE", etTitle.getText().toString());
                    extras.putString("BUILDER", etBuilder.getText().toString());
                    extras.putString("CATEGORY", spinnerCategory.getSelectedItem().toString());
                    i.putExtras(extras);
                    startActivityForResult(i, 1);
                }

            }
        });

        btnMainMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ActivityTwo.this, MainActivity.class));
            }
        });

        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.quizCategory, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        spinnerCategory.setAdapter(adapter);


    }

}
