package com.example.w0409174.quizbuilder;

import android.support.v7.app.AppCompatActivity;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {
    TextView tvQuizBuilder;
    Button btnBuildQuiz;
    Button btnExit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvQuizBuilder = (TextView) findViewById(R.id.tvTitle);
        btnBuildQuiz = (Button) findViewById(R.id.btnBuildQuiz);
        btnExit = (Button) findViewById(R.id.btnExit);

        btnBuildQuiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ActivityTwo.class));
            }
        });

        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                System.exit(0);
            }
        });




    }//end of onCreate
}//end of class
