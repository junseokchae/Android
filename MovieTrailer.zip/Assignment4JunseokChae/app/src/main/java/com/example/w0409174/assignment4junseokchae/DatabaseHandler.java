package com.example.w0409174.assignment4junseokchae;

import android.content.*;
import android.database.*;
import android.database.sqlite.*;

import com.example.w0409174.assignment4junseokchae.dummy.DummyContent;

import java.util.*;

public class DatabaseHandler extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 2;
    private static final String DATABASE_NAME = "MovieTrailers";
    private static final String TABLE_MOVIES = "Movies";
    private static final String KEY_ID = "id";
    private static final String KEY_VIDEOID = "VIDEOID";
    private static final String KEY_CONTENT = "CONTENT";
    private static final String KEY_DATE = "DATE";
    private static final String KEY_DETAILS = "DETAILS";
    private static final String KEY_THUMBSUP = "THUMBSUP";
    private static final String KEY_THUMBSDOWN = "THUMBSDOWN";

    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        //3rd argument to be passed is CursorFactory instance
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_CONTACTS_TABLE = "CREATE TABLE " + TABLE_MOVIES + "("
                + KEY_ID + " TEXT PRIMARY KEY," + KEY_VIDEOID + " TEXT ," +KEY_CONTENT + " TEXT," + KEY_DATE+ " TEXT,"
                + KEY_DETAILS + " TEXT," + KEY_THUMBSUP + " TEXT," + KEY_THUMBSDOWN + " TEXT" + ")";
        db.execSQL(CREATE_CONTACTS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MOVIES);

        // Create tables again
        onCreate(db);
    }

    void addMovie(DummyContent.DummyItem movie){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_ID, movie.getId());
        values.put(KEY_VIDEOID, movie.getVideoId());
        values.put(KEY_CONTENT, movie.getContent());
        values.put(KEY_DATE, movie.getDate());
        values.put(KEY_DETAILS, movie.getDetails());
        values.put(KEY_THUMBSUP, movie.getThumbsUp());
        values.put(KEY_THUMBSDOWN,movie.getThumbsDown());


        // Inserting Row  
        db.insert(TABLE_MOVIES, null, values);
        //2nd argument is String containing nullColumnHack  
        db.close(); // Closing database connection  
    }
    DummyContent.DummyItem getMovie(int id){
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_MOVIES, new String[] { KEY_ID,
                        KEY_VIDEOID, KEY_CONTENT, KEY_DATE, KEY_DETAILS, KEY_THUMBSUP, KEY_THUMBSDOWN}, KEY_ID + "=?",
                new String[] { String.valueOf(id) }, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();

        DummyContent.DummyItem movie = new DummyContent.DummyItem(cursor.getString(0),
                cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getString(5), cursor.getString(6));
        // return contact
        return movie;
    }

    // code to get all contacts in a list view
    public List<DummyContent.DummyItem> getAllMovies() {
        List<DummyContent.DummyItem> movieList = new ArrayList<DummyContent.DummyItem>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_MOVIES;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                DummyContent.DummyItem movie = new DummyContent.DummyItem();
                movie.setId(cursor.getString(0));
                movie.setVideoId(cursor.getString(1));
                movie.setContent(cursor.getString(2));
                movie.setDate(cursor.getString(3));
                movie.setDetails(cursor.getString(4));
                movie.setThumbsUp(cursor.getString(5));
                movie.setThumbsDown(cursor.getString(6));
                // Adding contact to list
                movieList.add(movie);
            } while (cursor.moveToNext());
        }

        // return contact list
        return movieList;
    }

    // code to update the single contact
    public int updateMovie(DummyContent.DummyItem movie) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_VIDEOID, movie.getVideoId());
        values.put(KEY_CONTENT, movie.getContent());
        values.put(KEY_DATE, movie.getDate());
        values.put(KEY_DETAILS, movie.getDetails());
        values.put(KEY_THUMBSUP, movie.getThumbsUp());
        values.put(KEY_THUMBSDOWN, movie.getThumbsDown());

        // updating row
        return db.update(TABLE_MOVIES, values, KEY_ID + " = ?",
                new String[] { String.valueOf(movie.getId()) });
    }

    // Deleting single contact
    public void deleteMovie(DummyContent.DummyItem movie) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_MOVIES, KEY_ID + " = ?",
                new String[] { String.valueOf(movie.getId()) });
        db.close();
    }

    // Getting contacts Count
    public int getMoviesCount() {
        String countQuery = "SELECT  * FROM " + TABLE_MOVIES;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        cursor.close();

        // return count
        return cursor.getCount();
    }
}
