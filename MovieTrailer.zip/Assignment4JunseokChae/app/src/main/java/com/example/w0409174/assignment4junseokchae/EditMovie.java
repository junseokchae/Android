package com.example.w0409174.assignment4junseokchae;

import android.content.Intent;
import android.os.*;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.*;

import com.example.w0409174.assignment4junseokchae.dummy.DummyContent;

import java.util.List;

import static com.example.w0409174.assignment4junseokchae.dummy.DummyContent.ITEMS;

public class EditMovie extends AppCompatActivity {
    TextView tvId, tvVideoId, tvTitle, tvDate, tvThumbnail, tvLikes, tvDislikes;
    EditText etId, etVideoId, etTitle, etDate, etThumbnail, etLikes, etDislikes;
    Button btnSave, btnCancel;
    String id, videoId, title, date, thumbnail, likes, dislikes, mode;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.editmovie);
        tvId = findViewById(R.id.tvId);
        tvVideoId = findViewById(R.id.tvVideoId);
        tvTitle = findViewById(R.id.tvTitle);
        tvDate = findViewById(R.id.tvDate);
        tvThumbnail = findViewById(R.id.tvThumbnail);
        tvLikes = findViewById(R.id.tvLikes);
        tvDislikes = findViewById(R.id.tvDislikes);
        etId = findViewById(R.id.etId);
        etVideoId = findViewById(R.id.etVideoId);
        etTitle = findViewById(R.id.etTitle);
        etDate = findViewById(R.id.etDate);
        etThumbnail = findViewById(R.id.etThumbnail);
        etLikes = findViewById(R.id.etLikes);
        etDislikes = findViewById(R.id.etDislikes);
        btnSave = findViewById(R.id.btnSave);
        btnCancel = findViewById(R.id.btnCancel);

        try{
            Bundle extras = getIntent().getExtras();
            if(extras != null){
                id = extras.getString("ID");
                videoId = extras.getString("VIDEOID");
                title = extras.getString("TITLE");
                date = extras.getString("DATE");
                thumbnail = extras.getString("THUMBNAIL");
                likes = extras.getString("LIKES");
                dislikes = extras.getString("DISLIKES");
                etId.setText(id);
                etVideoId.setText(videoId);
                etTitle.setText(title);
                etDate.setText(date);
                etThumbnail.setText(thumbnail);
                etLikes.setText(likes);
                etDislikes.setText(dislikes);
                mode = "edit";
            }
        }catch (Exception e){
            mode = "create";
        }
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseHandler db = new DatabaseHandler(EditMovie.this);
                //updateMovie
                //addMovie
                if(mode=="edit"){
                    db.updateMovie(new DummyContent.DummyItem(etId.getText().toString(),etVideoId.getText().toString(),etTitle.getText().toString(),etDate.getText().toString(),etThumbnail.getText().toString(),etLikes.getText().toString(),etDislikes.getText().toString()));
                    List<DummyContent.DummyItem> movies = db.getAllMovies();
                    ITEMS = movies;
                }
                else if(mode=="create"){
                    db.addMovie(new DummyContent.DummyItem(etId.getText().toString(),etVideoId.getText().toString(),etTitle.getText().toString(),etDate.getText().toString(),etThumbnail.getText().toString(),etLikes.getText().toString(),etDislikes.getText().toString()));
                    List<DummyContent.DummyItem> movies = db.getAllMovies();
                    ITEMS = movies;
                }
                startActivity(new Intent(EditMovie.this,MovieListActivity.class));
            }
        });
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(EditMovie.this,MovieListActivity.class));

            }
        });

    }
}
