package com.example.w0409174.assignment4junseokchae;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.util.*;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.example.w0409174.assignment4junseokchae.dummy.*;

import java.util.List;

import static com.example.w0409174.assignment4junseokchae.dummy.DummyContent.*;

/**
 * An activity representing a list of Movies. This activity
 * has different presentations for handset and tablet-size devices. On
 * handsets, the activity presents a list of items, which when touched,
 * lead to a {@link MovieDetailActivity} representing
 * item details. On tablets, the activity presents the list of items and
 * item details side-by-side using two vertical panes.
 */
public class MovieListActivity extends AppCompatActivity {

    /**
     * Whether or not the activity is in two-pane mode, i.e. running on a tablet
     * device.
     */
    private boolean mTwoPane;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DatabaseHandler db = new DatabaseHandler(this);
        // Reading all contacts
        Log.d("Reading: ", "Reading all contacts..");
        List<DummyContent.DummyItem> movies = db.getAllMovies();
        ITEMS = movies;

        setContentView(R.layout.activity_movie_list);
        if(ITEMS == null) {


            // Inserting Movies
            Log.d("Insert: ", "Inserting...");
            db.addMovie(new DummyContent.DummyItem("1", "xRc3WviXk2M", "Joker Teaser Trailer", "2019", "https://i.ytimg.com/vi/xRc3WviXk2M/default.jpg", "67000", "2100"));
            db.addMovie(new DummyContent.DummyItem("2", "AXbP_toJWq0", "Star Wars: The Rise of Skywalker Teaser Trailer", "2019", "https://i.ytimg.com/vi/AXbP_toJWq0/default.jpg", "29000", "4900"));
            db.addMovie(new DummyContent.DummyItem("3", "mEUsRi74lcY", "The Lion King Trailer #1", "2019", "https://i.ytimg.com/vi/mEUsRi74lcY/default.jpg", "23000", "858"));
            db.addMovie(new DummyContent.DummyItem("4", "YQ08zLS0hPE", "Avengers: Endgame First Look", "2019", "https://i.ytimg.com/vi/YQ08zLS0hPE/default.jpg", "17000", "222"));
            db.addMovie(new DummyContent.DummyItem("5", "AD10dDdEGmU", "The Dead Don't Die Trailer", "2019", "https://i.ytimg.com/vi/AD10dDdEGmU/default.jpg", "19000", "537"));
            // Reading all contacts
            Log.d("Reading: ", "Reading all contacts..");
            movies = db.getAllMovies();
            ITEMS = movies;
        /*
        DummyContent.DummyItem item1 = new DummyContent.DummyItem("1","xRc3WviXk2M","Joker Teaser Trailer","2019","https://i.ytimg.com/vi/xRc3WviXk2M/default.jpg","67000","2100");
        DummyContent.DummyItem item2 = new DummyContent.DummyItem("2","AXbP_toJWq0","Star Wars: The Rise of Skywalker Teaser Trailer","2019","https://i.ytimg.com/vi/AXbP_toJWq0/default.jpg","29000","4900");
        DummyContent.DummyItem item3 = new DummyContent.DummyItem("3","mEUsRi74lcY","The Lion King Trailer #1","2019","https://i.ytimg.com/vi/mEUsRi74lcY/default.jpg","23000","858");
        DummyContent.DummyItem item4 = new DummyContent.DummyItem("4","YQ08zLS0hPE","Avengers: Endgame First Look","2019","https://i.ytimg.com/vi/YQ08zLS0hPE/default.jpg","17000","222");
        DummyContent.DummyItem item5 = new DummyContent.DummyItem("5","AD10dDdEGmU","The Dead Don't Die Trailer","2019","https://i.ytimg.com/vi/AD10dDdEGmU/default.jpg","19000","537");
        addItem(item1);
        addItem(item2);
        addItem(item3);
        addItem(item4);
        addItem(item5);
        */
        }


        for (int i=0;i<ITEMS.size();i++){
            ITEM_MAP.put(ITEMS.get(i).id,ITEMS.get(i));
        }

        for (DummyContent.DummyItem mv : movies) {
            String log = "Id: " + mv.getId() + " ,VideoId: " + mv.getVideoId() + " ,Title: " +
                    mv.getContent() + ", Date: " + mv.getDate() + ", Thumbnails: " + mv.getDetails() + ", Likes: " + mv.getThumbsUp() + ", Dislike: " + mv.getThumbsDown();
            // Writing Contacts to log
            Log.d("Name: ", log);
        }

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle(getTitle());

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MovieListActivity.this,EditMovie.class));
            }
        });

        if (findViewById(R.id.movie_detail_container) != null) {
            // The detail container view will be present only in the
            // large-screen layouts (res/values-w900dp).
            // If this view is present, then the
            // activity should be in two-pane mode.
            mTwoPane = true;
        }

        View recyclerView = findViewById(R.id.movie_list);
        assert recyclerView != null;
        setupRecyclerView((RecyclerView) recyclerView);
    }



    private void setupRecyclerView(@NonNull RecyclerView recyclerView) {
        recyclerView.setAdapter(new SimpleItemRecyclerViewAdapter(this, ITEMS, mTwoPane));
    }

    public static class SimpleItemRecyclerViewAdapter
            extends RecyclerView.Adapter<SimpleItemRecyclerViewAdapter.ViewHolder> {

        private final MovieListActivity mParentActivity;
        private final List<DummyContent.DummyItem> mValues;
        private final boolean mTwoPane;
        private final View.OnClickListener mOnClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DummyContent.DummyItem item = (DummyContent.DummyItem) view.getTag();
                if (mTwoPane) {
                    Bundle arguments = new Bundle();
                    arguments.putString(MovieDetailFragment.ARG_ITEM_ID, item.videoId);
                    MovieDetailFragment fragment = new MovieDetailFragment();
                    fragment.setArguments(arguments);
                    mParentActivity.getSupportFragmentManager().beginTransaction()
                            .replace(R.id.movie_detail_container, fragment)
                            .commit();
                } else {
                    Context context = view.getContext();
                    Intent intent = new Intent(context, MovieDetailActivity.class);
                    intent.putExtra(MovieDetailFragment.ARG_ITEM_ID, item.id);

                    context.startActivity(intent);
                }
            }
        };

        SimpleItemRecyclerViewAdapter(MovieListActivity parent,
                                      List<DummyContent.DummyItem> items,
                                      boolean twoPane) {
            mValues = items;
            mParentActivity = parent;
            mTwoPane = twoPane;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.movie_list_content, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(final ViewHolder holder, int position) {
            holder.mIdView.setText(mValues.get(position).content); // show the title
            // holder.mContentView.setText(mValues.get(position).details); // show the url -> will show the thumbnail

            holder.itemView.setTag(mValues.get(position));
            holder.itemView.setOnClickListener(mOnClickListener);
        }

        @Override
        public int getItemCount() {
            return mValues.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            final TextView mIdView;
            final TextView mContentView;

            ViewHolder(View view) {
                super(view);
                mIdView = (TextView) view.findViewById(R.id.id_text);
                mContentView = (TextView) view.findViewById(R.id.content);
            }
        }
    }
}
