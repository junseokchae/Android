package com.example.w0409174.assignment4junseokchae;

import android.app.Activity;
import android.content.*;
import android.net.*;
import android.os.Build;
import android.support.design.widget.CollapsingToolbarLayout;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.*;
import android.webkit.*;
import android.webkit.WebView.*;
import android.widget.*;

import com.example.w0409174.assignment4junseokchae.dummy.DummyContent;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import static com.example.w0409174.assignment4junseokchae.dummy.DummyContent.ITEMS;

/**
 * A fragment representing a single Movie detail screen.
 * This fragment is either contained in a {@link MovieListActivity}
 * in two-pane mode (on tablets) or a {@link MovieDetailActivity}
 * on handsets.
 */
public class MovieDetailFragment extends Fragment {
    /**
     * The fragment argument representing the item ID that this fragment
     * represents.
     */
    public static final String ARG_ITEM_ID = "item_id";

    /**
     * The dummy content this fragment is presenting.
     */
    private DummyContent.DummyItem mItem;

    /**
     * Mandatory empty constructor for the fragment manager to instantiate the
     * fragment (e.g. upon screen orientation changes).
     */
    public MovieDetailFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments().containsKey(ARG_ITEM_ID)) {
            // Load the dummy content specified by the fragment
            // arguments. In a real-world scenario, use a Loader
            // to load content from a content provider.
            mItem = DummyContent.ITEM_MAP.get(getArguments().getString(ARG_ITEM_ID));

            Activity activity = this.getActivity();
            CollapsingToolbarLayout appBarLayout = (CollapsingToolbarLayout) activity.findViewById(R.id.toolbar_layout);
            if (appBarLayout != null) {
                new DownloadImageTask((ImageView)appBarLayout.findViewById(R.id.imageViewplaces)).execute(mItem.details);//show image
                appBarLayout.setTitle(mItem.content);//show title
            }
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.movie_detail, container, false);

        // Show the dummy content as text in a TextView.

        if (mItem != null) {
            Button btnPlay = rootView.findViewById(R.id.btnPlay);
            btnPlay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String url = "https://www.youtube.com/v/"+mItem.videoId;
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    startActivity(i);

                }
            });

            String content = "Title: " + mItem.content + "\nDate: " + mItem.date +"\nLikes: " + mItem.thumbsUp + "\nDislikes: " + mItem.thumbsDown;
            ((TextView) rootView.findViewById(R.id.movie_detail)).setText(content);
            ImageButton btnLike = rootView.findViewById(R.id.btnLike);
            btnLike.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    String thumbsUp = mItem.getThumbsUp();
                    int intThumbsUp = Integer.parseInt(thumbsUp) + 1;
                    thumbsUp = String.valueOf(intThumbsUp);
                    mItem.setThumbsUp(thumbsUp);
                    String content = "Title: " + mItem.content + "\nDate: " + mItem.date +"\nLikes: " + mItem.thumbsUp + "\nDislikes: " + mItem.thumbsDown;
                    ((TextView) rootView.findViewById(R.id.movie_detail)).setText(content);
                }
            });
            ImageButton btnDislike = rootView.findViewById(R.id.btnDislike);
            btnDislike.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    String thumbsDown = mItem.getThumbsDown();
                    int intThumbsDown = Integer.parseInt(thumbsDown) + 1;
                    thumbsDown = String.valueOf(intThumbsDown);
                    mItem.setThumbsDown(thumbsDown);
                    String content = "Title: " + mItem.content + "\nDate: " + mItem.date +"\nLikes: " + mItem.thumbsUp + "\nDislikes: " + mItem.thumbsDown;
                    ((TextView) rootView.findViewById(R.id.movie_detail)).setText(content);
                }
            });

            ImageButton btnDelete = rootView.findViewById(R.id.btnDelete);
            btnDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ITEMS.remove(ARG_ITEM_ID);
                    DatabaseHandler db = new DatabaseHandler(rootView.getContext());
                    db.deleteMovie(mItem);
                    Toast.makeText(rootView.getContext(),"ITEM REMOVED",Toast.LENGTH_SHORT).show();
                    List<DummyContent.DummyItem> movies = db.getAllMovies();
                    ITEMS = movies;
                }
            });

            ImageButton btnEdit = rootView.findViewById(R.id.btnEdit);
            btnEdit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent("EditMovie");
                    Bundle extras = new Bundle();
                    extras.putString("ID",mItem.getId());
                    extras.putString("VIDEOID",mItem.getVideoId());
                    extras.putString("TITLE",mItem.getContent());
                    extras.putString("DATE",mItem.getDate());
                    extras.putString("THUMBNAIL",mItem.getDetails());
                    extras.putString("LIKES",mItem.getThumbsUp());
                    extras.putString("DISLIKES",mItem.getThumbsDown());
                    i.putExtras(extras);
                    startActivityForResult(i,1);
                }
            });
        }



        return rootView;
    }

}
