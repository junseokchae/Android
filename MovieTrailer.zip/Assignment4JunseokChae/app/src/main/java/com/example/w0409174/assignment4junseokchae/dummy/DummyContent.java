package com.example.w0409174.assignment4junseokchae.dummy;

import com.example.w0409174.assignment4junseokchae.DatabaseHandler;
import com.example.w0409174.assignment4junseokchae.MovieListActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Helper class for providing sample content for user interfaces created by
 * Android template wizards.
 * <p>
 * TODO: Replace all uses of this class before publishing your app.
 */
public class DummyContent {

    /**
     * An array of sample (dummy) items.
     */
    public static List<DummyItem> ITEMS = new ArrayList<DummyItem>();

    /**
     * A map of sample (dummy) items, by ID.
     */
    public static final Map<String, DummyItem> ITEM_MAP = new HashMap<String, DummyItem>();

    private static final int COUNT = 25;




    static {






    }

    private static void addItem(DummyItem item) {
        ITEMS.add(item);
        ITEM_MAP.put(item.id, item);
    }

/*
    private static DummyItem createDummyItem(int position) {
        return new DummyItem(String.valueOf(position), "Item " + position, makeDetails(position));
    }

    private static String makeDetails(int position) {
        StringBuilder builder = new StringBuilder();
        builder.append("Details about Item: ").append(position);
        for (int i = 0; i < position; i++) {
            builder.append("\nMore details information here.");
        }
        return builder.toString();
    }
*/
    /**
     * A dummy item representing a piece of content.
     */
    public static class DummyItem {
        public String id;
        public String videoId;//to the list -> should be used in the detail
        public String content;//to the header of the detail -> should go to the list
        public String date;
        public String details;//to the detail of the detail -> should go to the header of the detail
        public String thumbsUp;
        public String thumbsDown;

        public DummyItem(String id, String videoId, String content, String date, String details, String thumbsUp, String thumbsDown) {
            this.id = id;
            this.videoId = videoId;
            this.content = content;
            this.date = date;
            this.details = details;
            this.thumbsUp = thumbsUp;
            this.thumbsDown = thumbsDown;
        }
        public DummyItem(){

        };

        public String getId(){
            String id = this.id;
            return id;
        }

        public void setId(String id){
            this.id = id;
        }
        public String getVideoId(){
            String videoId = this.videoId;
            return videoId;
        }

        public void setVideoId(String videoId){
            this.videoId = videoId;
        }

        public String getContent(){
            String content = this.content;
            return content;
        }

        public void setContent(String content){
            this.content = content;
        }

        public String getDate(){
            String date = this.date;
            return date;
        }

        public void setDate(String date){
            this.date = date;
        }

        public String getDetails(){
            String details = this.details;
            return details;
        }

        public void setDetails(String details){
            this.details = details;
        }

        public String getThumbsUp(){
            String thumbsUp = this.thumbsUp;
            return thumbsUp;
        }

        public void setThumbsUp(String newThumbsUp){
            this.thumbsUp = newThumbsUp;
        }

        public String getThumbsDown(){
            String thumbsDown = this.thumbsDown;
            return thumbsDown;
        }

        public void setThumbsDown(String newThumbsDown){
            this.thumbsDown = newThumbsDown;
        }

        @Override
        public String toString() {
            return content;
        }
    }
}
