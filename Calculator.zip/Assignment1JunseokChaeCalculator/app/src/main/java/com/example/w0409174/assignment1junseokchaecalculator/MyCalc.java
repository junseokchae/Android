package com.example.w0409174.assignment1junseokchaecalculator;

public class MyCalc {
    public String putNumberforProcess(int num, String process, String number, boolean hasOperator) {
        if(number.equals("Divided by Zero")){
            process = "";
        }
        else if(number.equals("0") && !process.equals("") && !hasOperator)
            process = process.substring(0,process.length()-1);
        process += Integer.toString(num);
        return process;
    }
    public String putNumberforNumber(int num, String process, String number, boolean hasOperator) {
        if(number.equals("Divided by Zero")){
            number = Integer.toString(num);
        }
        else if (number.equals("0") || hasOperator || number.equals("Divided by Zero")) {
            number = Integer.toString(num);
        }
        else {
            number += Integer.toString(num);
        }
        return number;
    }
    public String putPointforNumber(String process, String number){
        if (number.contains("."))//if number already has decimal points, it should do nothing.
            number = number;
        else//if it isn't it needs to have decimal point.
            number += ".";

        return number;
    }
    public String putPointforProcess(String process, String number){
        if (number.contains("."))
            process = process;
        else {
            if(process.equals(""))
                process = "0";
            else if(process.substring(process.length()-1).equals("+") || process.substring(process.length()-1).equals("*") || process.substring(process.length()-1).equals("/") || process.substring(process.length()-1).equals("-") || process.substring(process.length()-1).equals("%"))
                process = process.substring(0, process.length() - 1);
            process += ".";
        }

        return process;
    }
    public String addition(String process){
        String result = "";
        if (process.contains("+")){
            if(process.lastIndexOf("+") == process.length()-1){
                process = process.substring(0,process.length()-1);
                result = process;
            }
            else {
                String leftNum = process.substring(0, process.lastIndexOf("+"));
                String rightNum = process.substring(process.lastIndexOf("+") + 1);
                result = String.valueOf(Double.parseDouble(leftNum) + Double.parseDouble(rightNum));
            }

        }
        else
            result = process;
        return result;
    }
    public String subtraction(String process){
        String result = "";
        if (process.contains("-") && process.lastIndexOf("-") != 0){
            if(process.lastIndexOf("-") == process.length()-1){
                process = process.substring(0,process.length()-1);
                result = process;
            }
            else {
                String leftNum = process.substring(0, process.lastIndexOf("-"));
                String rightNum = process.substring(process.lastIndexOf("-") + 1);
                result = String.valueOf(Double.parseDouble(leftNum) - Double.parseDouble(rightNum));
            }
        }
        else
            result = process;
        return result;
    }
    public String multiplication(String process){
        String result = "";
        if (process.contains("*")){
            if(process.lastIndexOf("*") == process.length()-1) {
                process = process.substring(0, process.length() - 1);
                result = process;
            }
            else {
                String leftNum = process.substring(0, process.lastIndexOf("*"));
                String rightNum = process.substring(process.lastIndexOf("*") + 1);
                result = String.valueOf(Double.parseDouble(leftNum) * Double.parseDouble(rightNum));
            }
        }
        else
            result = process;
        return result;
    }
    public String division(String process){
        String result = "";
        if (process.contains("/")){
            if(process.lastIndexOf("/") == process.length()-1) {
                process = process.substring(0, process.length() - 1);
                result = process;
            }
            else {
                String leftNum = process.substring(0, process.lastIndexOf("/"));
                String rightNum = process.substring(process.lastIndexOf("/") + 1);
                if (rightNum.equals("0"))
                    result = "Divided by Zero";
                else
                    result = String.valueOf(Double.parseDouble(leftNum) / Double.parseDouble(rightNum));
            }
        }
        else
            result = process;
        return result;
    }
    public String modular(String process){
        String result = "";
        if (process.contains("%")){
            if(process.lastIndexOf("%") == process.length()-1) {
                process = process.substring(0, process.length() - 1);
                result = process;
            }
            else {
                String leftNum = process.substring(0, process.lastIndexOf("%"));
                String rightNum = process.substring(process.lastIndexOf("%") + 1);
                if (rightNum.equals("0"))
                    result = "Divided by Zero";
                else
                    result = String.valueOf(Double.parseDouble(leftNum) % Double.parseDouble(rightNum));
            }
        }
        else
            result = process;
        return result;
    }
    public String putOperations(String operation, String process){
        if (process.contains("Divided by Zero"))
            process = process;
        else if(process.substring(process.length()).equals("+") || process.substring(process.length()).equals("*") || process.substring(process.length()).equals("/") || process.substring(process.length()).equals("-")) {
            process = process.substring(0, process.length() - 1);
            process += operation;
        }
        else
            process += operation;
        return process;
    }
    public String changeSign(String number){
        if(number.contains("-"))
            number = number.substring(1,number.length());
        else
            number = "-"+number;
        return number;
    }

    public String optimizeNumbers(String number){
        if(number.contains(".")){
            String afterDecimal = number.substring(number.indexOf("."));
            if(afterDecimal.equals(".0"))
                number = number.substring(0,number.indexOf("."));

        }
        if(number.equals(""))
            number = "0";

        return number;
    }

    public String cleanProcessforCE(String process){
        if(process.contains("+"))
            process = process.substring(0,process.indexOf("+")+1);
        else if (process.contains("-") && process.lastIndexOf("-") != 0)
            process = process.substring(0,process.lastIndexOf("-")+1);
        else if (process.contains("*"))
            process = process.substring(0,process.indexOf("*")+1);
        else if (process.contains("/"))
            process = process.substring(0,process.indexOf("/")+1);
        else if (process.contains("%"))
            process = process.substring(0,process.indexOf("%")+1);
        else
            process = "";

        return process;
    }

    public String squareNumber(String number){
        if(!number.equals("Divided by Zero"))
            number = String.valueOf(Double.parseDouble(number)*Double.parseDouble(number));
        return number;
    }

    public String sqrtNumber(String number){
        if(!number.equals("Divided by Zero")) {
            Double result = Double.parseDouble(number);
            result = Math.sqrt(result);
            number = String.valueOf(result);
        }
        return number;
    }

    public String reciprocalNumber(String number) {
        if (!number.equals("Divided by Zero")){
            Double result = Double.parseDouble(number);
            result = 1 / result;
            number = String.valueOf(result);
        }
        return number;
    }


}
