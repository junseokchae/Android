package com.example.w0409174.assignment1junseokchaecalculator;

import android.support.v7.app.AppCompatActivity;
import android.os.*;
import android.view.*;
import android.widget.*;

public class MainActivity extends AppCompatActivity {
    Button btnMod,btnSqrt,btnSquare,btnReciprocalNumber,btnCE,btnC,btnBackspace,btnDivision,
            btnMultiply,btnSubtraction,btnAddition,btnEquation,btnZero,btnOne,btnTwo,btnThree,
            btnFour,btnFive,btnSix,btnSeven,btnEight,btnNine,btnChangeSign,btnPoint;
    TextView tvProcess,tvNumber;
    MyCalc myCalc;
    boolean hasOperator = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myCalc = new MyCalc();//instance of clean bus obj

        tvProcess = findViewById(R.id.tvProcess);
        tvNumber = findViewById(R.id.tvNumber);

        btnAddition = findViewById(R.id.btnAddition);
        btnBackspace = findViewById(R.id.btnBackspace);
        btnC = findViewById(R.id.btnC);
        btnCE = findViewById(R.id.btnCE);
        btnChangeSign = findViewById(R.id.btnChangeSign);
        btnDivision = findViewById(R.id.btnDivision);
        btnEight = findViewById(R.id.btnEight);
        btnEquation = findViewById(R.id.btnEquation);
        btnFive = findViewById(R.id.btnFive);
        btnFour = findViewById(R.id.btnFour);
        btnMod = findViewById(R.id.btnMod);
        btnMultiply = findViewById(R.id.btnMultiply);
        btnNine = findViewById(R.id.btnNine);
        btnOne = findViewById(R.id.btnOne);
        btnPoint = findViewById(R.id.btnPoint);
        btnReciprocalNumber = findViewById(R.id.btnReciprocalNumber);
        btnSeven = findViewById(R.id.btnSeven);
        btnSix = findViewById(R.id.btnSix);
        btnSqrt = findViewById(R.id.btnSqrt);
        btnSquare = findViewById(R.id.btnSquare);
        btnSubtraction = findViewById(R.id.btnSubtraction);
        btnThree = findViewById(R.id.btnThree);
        btnTwo = findViewById(R.id.btnTwo);
        btnZero = findViewById(R.id.btnZero);


        btnZero.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                int putNumber = 0;
                String number = tvNumber.getText().toString();
                String process = tvProcess.getText().toString();
                process = myCalc.putNumberforProcess(putNumber,process,number,hasOperator);
                number = myCalc.putNumberforNumber(putNumber,process,number,hasOperator);
                tvProcess.setText(process);
                tvNumber.setText(number);
                hasOperator = false;

            }
        });

        btnOne.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                int putNumber = 1;
                String number = tvNumber.getText().toString();
                String process = tvProcess.getText().toString();
                process = myCalc.putNumberforProcess(putNumber,process,number,hasOperator);
                number = myCalc.putNumberforNumber(putNumber,process,number,hasOperator);
                tvProcess.setText(process);
                tvNumber.setText(number);
                hasOperator = false;

            }
        });

        btnTwo.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                int putNumber = 2;
                String number = tvNumber.getText().toString();
                String process = tvProcess.getText().toString();
                process = myCalc.putNumberforProcess(putNumber,process,number,hasOperator);
                number = myCalc.putNumberforNumber(putNumber,process,number,hasOperator);
                tvProcess.setText(process);
                tvNumber.setText(number);
                hasOperator = false;

            }
        });

        btnThree.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                int putNumber = 3;
                String number = tvNumber.getText().toString();
                String process = tvProcess.getText().toString();
                process = myCalc.putNumberforProcess(putNumber,process,number,hasOperator);
                number = myCalc.putNumberforNumber(putNumber,process,number,hasOperator);
                tvProcess.setText(process);
                tvNumber.setText(number);
                hasOperator = false;

            }
        });

        btnFour.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                int putNumber = 4;
                String number = tvNumber.getText().toString();
                String process = tvProcess.getText().toString();
                process = myCalc.putNumberforProcess(putNumber,process,number,hasOperator);
                number = myCalc.putNumberforNumber(putNumber,process,number,hasOperator);
                tvProcess.setText(process);
                tvNumber.setText(number);
                hasOperator = false;

            }
        });

        btnFive.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                int putNumber = 5;
                String number = tvNumber.getText().toString();
                String process = tvProcess.getText().toString();
                process = myCalc.putNumberforProcess(putNumber,process,number,hasOperator);
                number = myCalc.putNumberforNumber(putNumber,process,number,hasOperator);
                tvProcess.setText(process);
                tvNumber.setText(number);
                hasOperator = false;

            }
        });

        btnSix.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                int putNumber = 6;
                String number = tvNumber.getText().toString();
                String process = tvProcess.getText().toString();
                process = myCalc.putNumberforProcess(putNumber,process,number,hasOperator);
                number = myCalc.putNumberforNumber(putNumber,process,number,hasOperator);
                tvProcess.setText(process);
                tvNumber.setText(number);
                hasOperator = false;

            }
        });

        btnSeven.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                int putNumber = 7;
                String number = tvNumber.getText().toString();
                String process = tvProcess.getText().toString();
                process = myCalc.putNumberforProcess(putNumber,process,number,hasOperator);
                number = myCalc.putNumberforNumber(putNumber,process,number,hasOperator);
                tvProcess.setText(process);
                tvNumber.setText(number);
                hasOperator = false;

            }
        });

        btnEight.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                int putNumber = 8;
                String number = tvNumber.getText().toString();
                String process = tvProcess.getText().toString();
                process = myCalc.putNumberforProcess(putNumber,process,number,hasOperator);
                number = myCalc.putNumberforNumber(putNumber,process,number,hasOperator);
                tvProcess.setText(process);
                tvNumber.setText(number);
                hasOperator = false;

            }
        });

        btnNine.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                int putNumber = 9;
                String number = tvNumber.getText().toString();
                String process = tvProcess.getText().toString();
                process = myCalc.putNumberforProcess(putNumber,process,number,hasOperator);
                number = myCalc.putNumberforNumber(putNumber,process,number,hasOperator);
                tvProcess.setText(process);
                tvNumber.setText(number);
                hasOperator = false;

            }
        });

        btnPoint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String number = tvNumber.getText().toString();
                if(!number.equals("Divided by Zero")) {
                    String process = tvProcess.getText().toString();
                    process = myCalc.putPointforProcess(process, number);
                    number = myCalc.putPointforNumber(process, number);
                    tvProcess.setText(process);
                    tvNumber.setText(number);
                    hasOperator = false;
                }
            }
        });

        btnAddition.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                String process = tvProcess.getText().toString();
                String number = tvNumber.getText().toString();
                if(!number.equals("Divided by Zero")) {
                    if (process.equals(""))
                        process = number;
                    process = myCalc.addition(process);
                    process = myCalc.subtraction(process);
                    process = myCalc.multiplication(process);
                    process = myCalc.division(process);
                    process = myCalc.modular(process);
                    if (process.equals(""))
                        process = "0";
                    tvNumber.setText(process);
                    number = tvNumber.getText().toString();
                    number = myCalc.optimizeNumbers(number);
                    tvNumber.setText(number);
                    process = myCalc.putOperations("+", process);
                    tvProcess.setText(process);
                    hasOperator = true;
                }

            }
        });

        btnSubtraction.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                String process = tvProcess.getText().toString();
                String number = tvNumber.getText().toString();
                if(!number.equals("Divided by Zero")) {
                    if(process.equals(""))
                        process = number;
                    process = myCalc.addition(process);
                    process = myCalc.subtraction(process);
                    process = myCalc.multiplication(process);
                    process = myCalc.division(process);
                    process = myCalc.modular(process);
                    if(process.equals(""))
                        process = "0";
                    tvNumber.setText(process);
                    number = tvNumber.getText().toString();
                    number = myCalc.optimizeNumbers(number);
                    tvNumber.setText(number);
                    process = myCalc.putOperations("-",process);
                    tvProcess.setText(process);
                    hasOperator = true;
                }

            }
        });

        btnMultiply.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                String process = tvProcess.getText().toString();
                String number = tvNumber.getText().toString();
                if(!number.equals("Divided by Zero")) {
                    if(process.equals(""))
                        process = number;
                    process = myCalc.addition(process);
                    process = myCalc.subtraction(process);
                    process = myCalc.multiplication(process);
                    process = myCalc.division(process);
                    process = myCalc.modular(process);
                    if(process.equals(""))
                        process = "0";
                    tvNumber.setText(process);
                    number = tvNumber.getText().toString();
                    number = myCalc.optimizeNumbers(number);
                    tvNumber.setText(number);
                    process = myCalc.putOperations("*",process);
                    tvProcess.setText(process);
                    hasOperator = true;
                }
            }
        });

        btnDivision.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                String process = tvProcess.getText().toString();
                String number = tvNumber.getText().toString();
                if(!number.equals("Divided by Zero")) {
                    if(process.equals(""))
                        process = number;
                    process = myCalc.addition(process);
                    process = myCalc.subtraction(process);
                    process = myCalc.multiplication(process);
                    process = myCalc.division(process);
                    process = myCalc.modular(process);
                    if(process.equals(""))
                        process = "0";
                    tvNumber.setText(process);
                    number = tvNumber.getText().toString();
                    number = myCalc.optimizeNumbers(number);
                    tvNumber.setText(number);
                    process = myCalc.putOperations("/",process);
                    tvProcess.setText(process);
                    hasOperator = true;
                }
            }
        });

        btnMod.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                String process = tvProcess.getText().toString();
                String number = tvNumber.getText().toString();
                if(!number.equals("Divided by Zero")) {
                    if(process.equals(""))
                        process = number;
                    process = myCalc.addition(process);
                    process = myCalc.subtraction(process);
                    process = myCalc.multiplication(process);
                    process = myCalc.division(process);
                    process = myCalc.modular(process);
                    if(process.equals(""))
                        process = "0";
                    tvNumber.setText(process);
                    number = tvNumber.getText().toString();
                    number = myCalc.optimizeNumbers(number);
                    tvNumber.setText(number);
                    process = myCalc.putOperations("%",process);
                    tvProcess.setText(process);
                    hasOperator = true;
                }
            }
        });

        btnEquation.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                String process = tvProcess.getText().toString();
                String number = tvNumber.getText().toString();
                if(!number.equals("Divided by Zero")) {
                    if(process.equals(""))
                        process = number;
                    process = myCalc.addition(process);
                    process = myCalc.subtraction(process);
                    process = myCalc.multiplication(process);
                    process = myCalc.division(process);
                    process = myCalc.modular(process);
                    if(process.equals(""))
                        process = "0";
                    tvNumber.setText(process);
                    number = tvNumber.getText().toString();
                    number = myCalc.optimizeNumbers(number);
                    tvNumber.setText(number);
                    tvProcess.setText("");
                }
            }
        });

        btnChangeSign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String process = tvProcess.getText().toString();
                String number = tvNumber.getText().toString();
                if(!number.equals("Divided by Zero")) {
                    if(process!=""){
                        process = myCalc.addition(process);
                        process = myCalc.subtraction(process);
                        process = myCalc.multiplication(process);
                        process = myCalc.division(process);
                        process = myCalc.modular(process);
                    }
                    else
                        process = number;
                    tvNumber.setText(process);
                    number = tvNumber.getText().toString();
                    number = myCalc.changeSign(number);
                    tvNumber.setText(number);
                    number = tvNumber.getText().toString();
                    number = myCalc.optimizeNumbers(number);
                    tvNumber.setText(number);
                    tvProcess.setText("");
                }

            }
        });

        btnC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvNumber.setText("0");
                tvProcess.setText("");
            }
        });

        btnCE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String process = tvProcess.getText().toString();
                process = myCalc.cleanProcessforCE(process);
                tvProcess.setText(process);
                tvNumber.setText("0");
            }
        });

        btnSquare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String process = tvProcess.getText().toString();
                String number = tvNumber.getText().toString();
                if(!number.equals("Divided by Zero")) {
                    if(process!=""){
                        process = myCalc.addition(process);
                        process = myCalc.subtraction(process);
                        process = myCalc.multiplication(process);
                        process = myCalc.division(process);
                        process = myCalc.modular(process);
                    }
                    else
                        process = number;
                    if(process.equals(""))
                        process = "0";
                    tvNumber.setText(process);
                    number = tvNumber.getText().toString();
                    number = myCalc.squareNumber(number);
                    number = myCalc.optimizeNumbers(number);
                    tvNumber.setText(number);
                    tvProcess.setText("");
                }
            }
        });

        btnSqrt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String process = tvProcess.getText().toString();
                String number = tvNumber.getText().toString();
                if(!number.equals("Divided by Zero")) {
                    if(process!=""){
                        process = myCalc.addition(process);
                        process = myCalc.subtraction(process);
                        process = myCalc.multiplication(process);
                        process = myCalc.division(process);
                        process = myCalc.modular(process);
                    }
                    else
                        process = number;
                    if(process.equals(""))
                        process = "0";
                    tvNumber.setText(process);
                    number = tvNumber.getText().toString();
                    number = myCalc.sqrtNumber(number);
                    number = myCalc.optimizeNumbers(number);
                    tvNumber.setText(number);
                    tvProcess.setText("");
                }
            }
        });

        btnReciprocalNumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String process = tvProcess.getText().toString();
                String number = tvNumber.getText().toString();
                if(!number.equals("Divided by Zero")) {
                    if(process!=""){
                        process = myCalc.addition(process);
                        process = myCalc.subtraction(process);
                        process = myCalc.multiplication(process);
                        process = myCalc.division(process);
                        process = myCalc.modular(process);
                    }
                    else
                        process = number;
                    tvNumber.setText(process);
                    number = tvNumber.getText().toString();
                    number = myCalc.reciprocalNumber(number);
                    number = myCalc.optimizeNumbers(number);
                    tvNumber.setText(number);
                    tvProcess.setText("");
                }
            }
        });
        btnBackspace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String process = tvProcess.getText().toString();
                String number = tvNumber.getText().toString();
                if(!number.equals("Divided by Zero")) {
                    if(!process.substring(process.length()-1).equals("+") &&
                            !process.substring(process.length()-1).equals("-") &&
                            !process.substring(process.length()-1).equals("*") &&
                            !process.substring(process.length()-1).equals("%")) {
                        if (number.length() == 1)
                            number = "0";
                        else
                            number = number.substring(0, number.length() - 1);
                        number = myCalc.optimizeNumbers(number);
                    }
                    else
                        hasOperator = false;
                    tvNumber.setText(number);
                    if(!process.equals("")) {
                        if(process.length() >= 2)
                            process = process.substring(0, process.length() - 1);
                        else
                            process = "";
                        tvProcess.setText(process);
                    }
                }
            }
        });

    }//end of onCreate
}//end class
